dtree.py		Decision Tree code for you to edit.
mush.py			Runs the mushroom tests.  You may need to edit.
mush_test.ssv		Testing data
mush_train.ssv		Training data
mush_valid.ssv		Validation data for pruning only
Readme.txt		This file
tennis.data		Tennis data
tennis.py		Running tennis example
tennprune5.dat		Simple test of pruning.
